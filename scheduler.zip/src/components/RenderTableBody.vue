<template>
   <div class="app-table-grid__item-body">{{dick}}</div>
</template>

<script>
export default {
     name: 'RenderTableBody',
     props: {
         dick: String
     }
}
</script>

<style>

</style>