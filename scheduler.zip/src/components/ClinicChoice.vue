<template>
<!-- <it-select v-model="selectedClinic" option-label="name" placeholder="Выберите клинику" :options="clinics" /> -->
<!-- <vue-select
  v-model="selectedClinic"
  :options="clinics"
  label-by="name"
  :track-by="clinic => name"
  :min="1"
></vue-select> -->
   <select name="selectClinic" v-model="selectedClinic" class="form-control clinic-select" @change="chooseClinic(selectedClinic)">
       <option value="" disabled hidden class="form-control">Выберите клинику</option>
       <option v-for="clinic in clinics" :key="clinic.id" :value="clinic" placeholder="sad">
   {{ clinic.name }}
       </option>
   </select>
   <!-- {{ selectedClinic }} -->
</template>

<script>
 
export default {

    data() {
        return {
            selectedClinic: ""

    //         model: null,
    //   options: [
    //     { language: 'JavaScript' },
    //     { language: 'Python' },
    //     { language: 'PHP' },
    //   ],
            // clinics: [
            //     {
            //         id: 1,
            //         name: "ara clinic"
            //     },
            //     {
            //         id: 3,
            //         name: "ebanaya clinic"
            //     },
            //     {
            //         id: 2,
            //         name: "araped clinic"
            //     },
            // ]
        }
    },
    mounted() {
//         if(this.selectedClinic==="") {
// // this.selectedClinic = this.clinics[0];
// console.log(this.selectedClinic)}
    },
    methods:{
        chooseClinic(payload) {
            this.$store.commit("CHOOSE_CLINIC", payload);
        }
    },
    computed: {
        clinics() {
            return this.$store.getters.GET_CLINICS;
        },
        
}
}

</script>

<style>
.clinic-select {
    margin-top: 20px;
}
</style>