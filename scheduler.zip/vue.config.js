module.exports = {
    publicPath: '/vue-scheduler/'
}